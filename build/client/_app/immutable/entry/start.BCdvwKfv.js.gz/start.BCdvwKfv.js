import{l as o,a as r}from"../chunks/DAVta-Xa.js";export{o as load_css,r as start};
